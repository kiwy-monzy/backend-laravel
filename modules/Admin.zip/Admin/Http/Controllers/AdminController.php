<?php

namespace Modules\Admin\Http\Controllers;

use App\Http\Controllers\Web\ModuleController;
use App\Models\Organization;
use App\Models\OrganizationMember;
use App\Models\User;

/**
 * The administration hub.
 *
 * **A landing surface, not a re-homing of the working pages.** The system,
 * users, team, access and subscription pages already exist and are gated
 * correctly; moving them under this module would churn dozens of route names
 * for no gain. Instead this is the one place an administrator lands to see the
 * state of the organization — and, for a system admin, the whole installation
 * — with the links to act on it. The module is admin-only by default (it is in
 * `Access::ADMIN_ONLY`), so it simply does not appear for anyone else.
 */
class AdminController extends ModuleController
{
    protected string $module = 'admin';

    public function index()
    {
        $me = $this->me();
        $org = $this->organization();

        return view('admin::index', [
            'organization' => $org,
            'isSystemAdmin' => $me->isSystemAdmin(),
            // The organization at a glance.
            'orgStats' => [
                'members' => OrganizationMember::where('organization_id', $org?->id)->count(),
                'unverified' => User::where('organization_id', $org?->id)->whereNull('email_verified_at')->count(),
                'websites' => $org ? $org->websites()->count() : 0,
                'modules' => $org ? $org->moduleGrants()->where('granted', true)->count() : 0,
            ],
            // The installation, for a system admin only.
            'systemStats' => $me->isSystemAdmin() ? [
                'organizations' => Organization::count(),
                'users' => User::count(),
                'owners' => User::where('role', 'owner')->count(),
            ] : null,
            // Who has no seat, and who is unverified — the two things an
            // administrator most often needs to chase.
            'unseated' => User::where('organization_id', $org?->id)
                ->whereNotIn('id', OrganizationMember::where('organization_id', $org?->id)->pluck('user_id'))
                ->limit(10)->get(),
            'unverified' => User::where('organization_id', $org?->id)
                ->whereNull('email_verified_at')
                ->limit(10)->get(),
        ]);
    }
}
