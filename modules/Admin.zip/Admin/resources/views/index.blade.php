@extends('layouts.app')
@section('title', __('Administration'))

@section('content')
    <h1>{{ __('Administration') }}</h1>
    <p class="sub">{{ $organization?->name }}</p>

    @if ($isSystemAdmin && $systemStats)
        <h2>{{ __('Installation') }}</h2>
        <div class="grid c3">
            <a class="stat" href="{{ route('system.index') }}">
                <div class="n">{{ number_format($systemStats['organizations']) }}</div><div class="k">{{ __('Organizations') }}</div>
            </a>
            <a class="stat" href="{{ route('system.users') }}">
                <div class="n">{{ number_format($systemStats['users']) }}</div><div class="k">{{ __('Users') }}</div>
            </a>
            <div class="stat"><div class="n">{{ number_format($systemStats['owners']) }}</div><div class="k">{{ __('Owners') }}</div></div>
        </div>
    @endif

    <h2>{{ __('This organization') }}</h2>
    <div class="grid c4">
        <a class="stat" href="{{ route('organization.team') }}">
            <div class="n">{{ number_format($orgStats['members']) }}</div><div class="k">{{ __('Team members') }}</div>
        </a>
        <a class="stat @if ($orgStats['unverified']) warn @endif" href="{{ route('contact.index') }}">
            <div class="n">{{ number_format($orgStats['unverified']) }}</div><div class="k">{{ __('Unverified') }}</div>
        </a>
        <div class="stat"><div class="n">{{ number_format($orgStats['websites']) }}</div><div class="k">{{ __('Websites') }}</div></div>
        <a class="stat" href="{{ route('organization.access') }}">
            <div class="n">{{ number_format($orgStats['modules']) }}</div><div class="k">{{ __('Modules granted') }}</div>
        </a>
    </div>

    <div class="grid c2" style="margin-top:16px">
        <div class="card">
            <h2 style="margin-top:0">{{ __('Manage') }}</h2>
            <table>
                <tr><td><a href="{{ route('organization.edit') }}">{{ __('Organization profile') }}</a></td>
                    <td class="dim small">{{ __('Name, contact, currency') }}</td></tr>
                <tr><td><a href="{{ route('organization.team') }}">{{ __('Team & roles') }}</a></td>
                    <td class="dim small">{{ __('Add people, set roles and employee types') }}</td></tr>
                <tr><td><a href="{{ route('organization.access') }}">{{ __('Module access') }}</a></td>
                    <td class="dim small">{{ __('Which roles reach which modules') }}</td></tr>
                <tr><td><a href="{{ route('organization.subscription') }}">{{ __('Subscription & plan') }}</a></td>
                    <td class="dim small">{{ __('Plan and status') }}</td></tr>
                <tr><td><a href="{{ route('users.index') }}">{{ __('User accounts') }}</a></td>
                    <td class="dim small">{{ __('Logins across the organization') }}</td></tr>
                <tr><td><a href="{{ route('contact.index') }}">{{ __('Verification & resets') }}</a></td>
                    <td class="dim small">{{ __('Send verify / reset links') }}</td></tr>
                @if ($isSystemAdmin)
                    <tr><td><a href="{{ route('system.index') }}">{{ __('System (all organizations)') }}</a></td>
                        <td class="dim small">{{ __('Create orgs, grant modules') }}</td></tr>
                @endif
            </table>
        </div>

        <div>
            @if ($unseated->isNotEmpty())
                <div class="card">
                    <h2 style="margin-top:0">{{ __('No team seat') }}</h2>
                    <p class="dim small">{{ __('These accounts belong to the organization but hold no seat, so they can open nothing.') }}</p>
                    <table>
                        @foreach ($unseated as $u)
                            <tr><td>{{ $u->username }}</td><td class="dim small">{{ $u->email }}</td>
                                <td class="right-align"><a class="small" href="{{ route('organization.team') }}">{{ __('seat') }}</a></td></tr>
                        @endforeach
                    </table>
                </div>
            @endif

            @if ($unverified->isNotEmpty())
                <div class="card">
                    <h2 style="margin-top:0">{{ __('Unverified email') }}</h2>
                    <table>
                        @foreach ($unverified as $u)
                            <tr><td>{{ $u->username }}</td><td class="dim small">{{ $u->email }}</td>
                                <td class="right-align"><a class="small" href="{{ route('contact.index') }}">{{ __('verify') }}</a></td></tr>
                        @endforeach
                    </table>
                </div>
            @endif
        </div>
    </div>
@endsection
