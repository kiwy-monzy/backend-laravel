<?php

use Illuminate\Support\Facades\Route;
use Modules\Admin\Http\Controllers\AdminController;

/*
| The administration hub, at /admin/m/admin. Admin-only (it is listed in
| Access::ADMIN_ONLY), and a landing surface for the system, users, team,
| access and subscription pages rather than a home for them.
*/

Route::get('/', [AdminController::class, 'index'])->name('index');
