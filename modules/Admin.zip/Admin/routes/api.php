<?php

use Modules\Admin\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;

/*
| Mounted at /api/admin behind bearer-token auth. Names are prefixed
| `api.admin.` so they cannot collide with the web routes above.
*/

Route::get('/', [AdminController::class, 'apiIndex'])->name('index');
